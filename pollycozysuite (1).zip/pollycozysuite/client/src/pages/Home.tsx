import Navigation from "@/components/Navigation";
import HeroSection from "@/components/HeroSection";
import PropertyOverview from "@/components/PropertyOverview";
import ImageGallery from "@/components/ImageGallery";
import AmenitiesSection from "@/components/AmenitiesSection";
import ReviewsSection from "@/components/ReviewsSection";
import LocationSection from "@/components/LocationSection";
import BookingSection from "@/components/BookingSection";
import HostSection from "@/components/HostSection";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      <HeroSection />
      <PropertyOverview />
      <ImageGallery />
      <AmenitiesSection />
      <ReviewsSection />
      <LocationSection />
      <BookingSection />
      <HostSection />
      <Footer />
    </div>
  );
}
