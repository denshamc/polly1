export const propertyImages = [
  {
    src: "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=1920&h=1080",
    alt: "Spacious living room with comfortable seating"
  },
  {
    src: "https://images.unsplash.com/photo-1631049307264-da0ec9d70304?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Elegant master bedroom with king-size bed"
  },
  {
    src: "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Fully equipped modern kitchen"
  },
  {
    src: "https://images.unsplash.com/photo-1552321554-5fefe8c9ef14?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600",
    alt: "Modern bathroom with premium fixtures"
  }
];

export const amenitiesList = [
  {
    category: "Entertainment",
    items: [
      "55 inch HDTV with standard cable",
      "Books and reading material",
      "Children's books and toys",
      "Board games"
    ]
  },
  {
    category: "Kitchen and Dining",
    items: [
      "Full kitchen with gas stove",
      "Refrigerator and freezer",
      "Microwave",
      "Cooking basics (pots, pans, oil, salt, pepper)",
      "Dishes and silverware",
      "Dining table"
    ]
  },
  {
    category: "Bedroom and Laundry",
    items: [
      "Cotton bed linens",
      "Extra pillows and blankets",
      "Room-darkening shades",
      "Iron",
      "Walk-in closet and dresser storage"
    ]
  },
  {
    category: "Bathroom",
    items: [
      "Bathtub",
      "Hair dryer",
      "Cleaning products",
      "Suave shampoo and conditioner",
      "Aveeno body soap",
      "Hot water"
    ]
  }
];

export const locationHighlights = [
  {
    category: "Transportation",
    items: [
      "J, Z, A, C, #3 train lines nearby",
      "Q24, B15, B14, B6 bus routes",
      "22 minutes to JFK Airport",
      "22 minutes to Downtown Brooklyn",
      "Easy access to Manhattan"
    ]
  },
  {
    category: "Dining & Entertainment",
    items: [
      "Caribbean cuisine restaurants",
      "Olive Garden, Applebee's nearby",
      "Dave & Buster's entertainment",
      "Chinese restaurants",
      "Pizza and fast food options"
    ]
  },
  {
    category: "Shopping & Attractions",
    items: [
      "Gateway Mall shopping center",
      "Barclays Center (22 minutes)",
      "Local grocery stores",
      "Neighborhood parks"
    ]
  }
];
