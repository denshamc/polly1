import { Mail, Phone, MapPin } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-navy text-white py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-3 gap-8">
          <div>
            <h3 className="font-playfair text-2xl font-bold mb-4">Polly's Cozy Suite</h3>
            <p className="text-white/80 leading-relaxed">
              Your comfortable home away from home in Brooklyn. Experience warmth, comfort, and exceptional hospitality 
              in our thoughtfully appointed cozy suite.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Quick Links</h4>
            <ul className="space-y-2 text-white/80">
              <li>
                <button 
                  onClick={() => scrollToSection('property')}
                  className="hover:text-white transition-colors"
                >
                  Property Details
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('amenities')}
                  className="hover:text-white transition-colors"
                >
                  Amenities
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('reviews')}
                  className="hover:text-white transition-colors"
                >
                  Guest Reviews
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('location')}
                  className="hover:text-white transition-colors"
                >
                  Location
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-lg mb-4">Contact</h4>
            <div className="space-y-3 text-white/80">
              <div className="flex items-center">
                <Mail className="mr-3 w-5 h-5" />
                <span>hello@pollyscozysuite.com</span>
              </div>
              <div className="flex items-center">
                <Phone className="mr-3 w-5 h-5" />
                <span>Available through messaging</span>
              </div>
              <div className="flex items-center">
                <MapPin className="mr-3 w-5 h-5" />
                <span>Brooklyn, New York</span>
              </div>
            </div>
          </div>
        </div>
        
        <div className="border-t border-white/20 mt-12 pt-8 text-center text-white/60">
          <p>&copy; 2024 Polly's Cozy Suite. All rights reserved. | Comfortable vacation rental in Brooklyn, NY</p>
        </div>
      </div>
    </footer>
  );
}
