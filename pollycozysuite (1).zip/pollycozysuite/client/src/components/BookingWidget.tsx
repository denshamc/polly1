import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import type { InsertBooking } from "@shared/schema";

interface BookingWidgetProps {
  isHero: boolean;
}

export default function BookingWidget({ isHero }: BookingWidgetProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const [checkinDate, setCheckinDate] = useState("");
  const [checkoutDate, setCheckoutDate] = useState("");
  const [guestCount, setGuestCount] = useState("1");
  const [specialRequests, setSpecialRequests] = useState("");
  const [guestName, setGuestName] = useState("");
  const [guestEmail, setGuestEmail] = useState("");

  const { data: property } = useQuery({
    queryKey: ["/api/property"],
  });

  const createBookingMutation = useMutation({
    mutationFn: async (booking: InsertBooking) => {
      const response = await apiRequest("POST", "/api/bookings", booking);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Booking Submitted!",
        description: "Your booking request has been submitted successfully. You will receive a confirmation email shortly.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/bookings"] });
      // Reset form
      setCheckinDate("");
      setCheckoutDate("");
      setGuestCount("1");
      setSpecialRequests("");
      setGuestName("");
      setGuestEmail("");
    },
    onError: (error: any) => {
      toast({
        title: "Booking Failed",
        description: error.message || "Failed to submit booking request. Please try again.",
        variant: "destructive",
      });
    },
  });

  const calculateTotal = () => {
    if (!checkinDate || !checkoutDate || !property) return 0;
    
    const startDate = new Date(checkinDate);
    const endDate = new Date(checkoutDate);
    const nights = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
    
    if (nights <= 0) return 0;
    
    const subtotal = property.basePrice * nights;
    return subtotal + property.cleaningFee;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!checkinDate || !checkoutDate) {
      toast({
        title: "Missing Dates",
        description: "Please select check-in and check-out dates.",
        variant: "destructive",
      });
      return;
    }

    if (!isHero && (!guestName || !guestEmail)) {
      toast({
        title: "Missing Information",
        description: "Please provide your name and email address.",
        variant: "destructive",
      });
      return;
    }

    const total = calculateTotal();
    if (total <= 0) {
      toast({
        title: "Invalid Dates",
        description: "Please select valid check-in and check-out dates.",
        variant: "destructive",
      });
      return;
    }

    const bookingData: InsertBooking = {
      guestName: guestName || "Guest",
      guestEmail: guestEmail || "guest@example.com",
      checkinDate,
      checkoutDate,
      guestCount: parseInt(guestCount),
      specialRequests: specialRequests || null,
      totalAmount: total.toString(),
    };

    createBookingMutation.mutate(bookingData);
  };

  const today = new Date().toISOString().split('T')[0];
  const minCheckoutDate = checkinDate ? 
    new Date(new Date(checkinDate).getTime() + 24 * 60 * 60 * 1000).toISOString().split('T')[0] : 
    today;

  const nights = checkinDate && checkoutDate ? 
    Math.ceil((new Date(checkoutDate).getTime() - new Date(checkinDate).getTime()) / (1000 * 60 * 60 * 24)) : 
    0;

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="checkin" className="block text-sm font-medium text-charcoal mb-1">
            Check-in
          </Label>
          <Input
            type="date"
            id="checkin"
            value={checkinDate}
            onChange={(e) => setCheckinDate(e.target.value)}
            min={today}
            className="w-full"
            required
          />
        </div>
        <div>
          <Label htmlFor="checkout" className="block text-sm font-medium text-charcoal mb-1">
            Check-out
          </Label>
          <Input
            type="date"
            id="checkout"
            value={checkoutDate}
            onChange={(e) => setCheckoutDate(e.target.value)}
            min={minCheckoutDate}
            className="w-full"
            required
          />
        </div>
      </div>

      <div>
        <Label htmlFor="guests" className="block text-sm font-medium text-charcoal mb-1">
          Guests
        </Label>
        <Select value={guestCount} onValueChange={setGuestCount}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="1">1 guest</SelectItem>
            <SelectItem value="2">2 guests</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {!isHero && (
        <>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="name" className="block text-sm font-medium text-charcoal mb-1">
                Full Name
              </Label>
              <Input
                type="text"
                id="name"
                value={guestName}
                onChange={(e) => setGuestName(e.target.value)}
                placeholder="Your full name"
                required
              />
            </div>
            <div>
              <Label htmlFor="email" className="block text-sm font-medium text-charcoal mb-1">
                Email Address
              </Label>
              <Input
                type="email"
                id="email"
                value={guestEmail}
                onChange={(e) => setGuestEmail(e.target.value)}
                placeholder="your@email.com"
                required
              />
            </div>
          </div>

          <div>
            <Label htmlFor="requests" className="block text-sm font-medium text-charcoal mb-1">
              Special Requests
            </Label>
            <Select value={specialRequests} onValueChange={setSpecialRequests}>
              <SelectTrigger>
                <SelectValue placeholder="None" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="none">None</SelectItem>
                <SelectItem value="early-checkin">Early check-in</SelectItem>
                <SelectItem value="late-checkout">Late check-out</SelectItem>
                <SelectItem value="airport-transfer">Airport transfer</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {property && nights > 0 && (
            <div className="border-t border-gray-200 pt-6 space-y-4">
              <div className="flex justify-between items-center">
                <span className="text-lg">Base rate ({nights} nights)</span>
                <span className="text-lg font-semibold">
                  ${(property.basePrice * nights).toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-lg">Cleaning fee</span>
                <span className="text-lg font-semibold">
                  ${property.cleaningFee.toFixed(2)}
                </span>
              </div>
              <div className="flex justify-between items-center text-xl font-bold border-t border-gray-200 pt-4">
                <span>Total</span>
                <span>${calculateTotal().toFixed(2)}</span>
              </div>
            </div>
          )}
        </>
      )}

      <Button 
        type="submit"
        disabled={createBookingMutation.isPending}
        className="w-full bg-coral text-white hover:bg-coral/90 transition-colors"
      >
        {createBookingMutation.isPending ? "Processing..." : 
         isHero ? "Check Availability" : "Complete Booking"}
      </Button>

      {isHero && property && (
        <p className="text-center text-sm text-gray-500 mt-2">
          From <span className="font-semibold">${property.basePrice}/night</span>
        </p>
      )}

      {!isHero && (
        <p className="text-center text-sm text-gray-500 mt-4">
          Free cancellation before 48 hours of check-in
        </p>
      )}
    </form>
  );
}
