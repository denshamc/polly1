import BookingWidget from "@/components/BookingWidget";

export default function HeroSection() {
  return (
    <section className="relative h-screen overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-navy/40 to-transparent z-10"></div>
      
      {/* Hero Image */}
      <div className="relative h-full">
        <img 
          src="/attached_assets/airbnb 4.jpg" 
          alt="Luxury living room with elegant decor"
          className="absolute inset-0 w-full h-full object-cover"
        />
      </div>
      
      <div className="absolute inset-0 z-20 flex items-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
          <div className="max-w-2xl">
            <h1 className="font-playfair text-5xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Welcome to Polly's Cozy Suite
            </h1>
            <p className="text-xl text-white/90 mb-8 leading-relaxed">
              Experience warmth and comfort in this beautifully appointed 2-bedroom home, 
              perfectly located in a vibrant Brooklyn neighborhood with excellent connections.
            </p>
            
            {/* Quick Booking Widget */}
            <div className="bg-white rounded-2xl p-6 shadow-2xl max-w-md">
              <BookingWidget isHero={true} />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
