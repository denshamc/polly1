import { Star, CheckCircle, Briefcase, GraduationCap, MessageCircle, Heart } from "lucide-react";

export default function HostSection() {
  return (
    <section className="py-20 bg-warm-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="font-playfair text-4xl font-bold text-navy mb-12">Meet Your Host</h2>
          
          <div className="bg-white rounded-2xl p-8 shadow-sm">
            <div className="flex flex-col md:flex-row items-center md:items-start text-center md:text-left">
              <div className="w-32 h-32 bg-sophisticated-blue rounded-full flex items-center justify-center text-white text-4xl font-bold mb-6 md:mb-0 md:mr-8">
                P
              </div>
              
              <div className="flex-1">
                <h3 className="font-playfair text-3xl font-bold text-navy mb-4">Polly</h3>
                <div className="flex flex-col md:flex-row md:items-center md:justify-start justify-center mb-4 space-y-2 md:space-y-0 md:space-x-6">
                  <div className="flex items-center justify-center md:justify-start">
                    <Star className="text-warm-gold mr-2 w-5 h-5 fill-current" />
                    <span className="font-semibold">4.96</span>
                    <span className="text-gray-500 ml-1">Host rating</span>
                  </div>
                  <div className="flex items-center justify-center md:justify-start">
                    <CheckCircle className="text-sophisticated-blue mr-2 w-5 h-5" />
                    <span className="text-gray-600">Identity verified</span>
                  </div>
                </div>
                
                <div className="grid md:grid-cols-2 gap-4 text-sm text-gray-600 mb-6">
                  <div className="flex items-center justify-center md:justify-start">
                    <Briefcase className="mr-2 w-4 h-4" />
                    <span>Works at NYC H+H</span>
                  </div>
                  <div className="flex items-center justify-center md:justify-start">
                    <GraduationCap className="mr-2 w-4 h-4" />
                    <span>Grand Canyon University</span>
                  </div>
                  <div className="flex items-center justify-center md:justify-start">
                    <MessageCircle className="mr-2 w-4 h-4" />
                    <span>Speaks English</span>
                  </div>
                  <div className="flex items-center justify-center md:justify-start">
                    <Heart className="mr-2 w-4 h-4" />
                    <span>Loves hosting</span>
                  </div>
                </div>
                
                <p className="text-lg text-gray-600 leading-relaxed">
                  "I love hosting and ensuring every guest has a memorable stay. My goal is to provide 
                  a clean, comfortable, and welcoming environment where you can truly feel at home in my cozy suite."
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
