import BookingWidget from "@/components/BookingWidget";

export default function BookingSection() {
  return (
    <section id="booking" className="py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-br from-navy to-sophisticated-blue rounded-3xl p-8 md:p-12 text-white">
          <div className="text-center mb-10">
            <h2 className="font-playfair text-4xl font-bold mb-4">Ready to Book Your Stay?</h2>
            <p className="text-xl text-white/90">Experience warmth and comfort at Polly's Cozy Suite</p>
          </div>
          
          <div className="bg-white rounded-2xl p-8 text-charcoal">
            <BookingWidget isHero={false} />
          </div>
        </div>
      </div>
    </section>
  );
}
