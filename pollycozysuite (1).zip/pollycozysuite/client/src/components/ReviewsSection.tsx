import { useQuery } from "@tanstack/react-query";
import { Star } from "lucide-react";
import type { Review } from "@shared/schema";

export default function ReviewsSection() {
  const { data: reviews, isLoading } = useQuery({
    queryKey: ["/api/reviews"],
  });

  const { data: property } = useQuery({
    queryKey: ["/api/property"],
  });

  if (isLoading) {
    return (
      <section id="reviews" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">Loading reviews...</div>
        </div>
      </section>
    );
  }

  const displayedReviews = reviews?.slice(0, 6) || [];

  return (
    <section id="reviews" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-playfair text-4xl font-bold text-navy mb-6">Guest Reviews</h2>
          <div className="flex items-center justify-center mb-4">
            <div className="flex text-warm-gold text-2xl">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-6 h-6 fill-current" />
              ))}
            </div>
            <span className="ml-3 text-2xl font-bold text-charcoal">
              {property?.rating || "4.96"}
            </span>
          </div>
          <p className="text-lg text-gray-600">
            Based on {property?.reviewCount || reviews?.length || 0} verified guest reviews
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          {displayedReviews.map((review: Review) => (
            <div key={review.id} className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-sophisticated-blue rounded-full flex items-center justify-center text-white font-semibold">
                  {review.guestName.charAt(0)}
                </div>
                <div className="ml-3">
                  <p className="font-semibold text-charcoal">{review.guestName}</p>
                  <p className="text-sm text-gray-500">{review.location}</p>
                </div>
                <div className="ml-auto flex text-warm-gold">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
              </div>
              <p className="text-gray-600 leading-relaxed">
                "{review.reviewText}"
              </p>
              <p className="text-sm text-gray-400 mt-3">{review.stayDate}</p>
            </div>
          ))}
        </div>
        
        {property?.ratings && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.cleanliness}</div>
              <p className="text-gray-600">Cleanliness</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.accuracy}</div>
              <p className="text-gray-600">Accuracy</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.checkin}</div>
              <p className="text-gray-600">Check-in</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.communication}</div>
              <p className="text-gray-600">Communication</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.location}</div>
              <p className="text-gray-600">Location</p>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-navy mb-2">{property.ratings.value}</div>
              <p className="text-gray-600">Value</p>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
