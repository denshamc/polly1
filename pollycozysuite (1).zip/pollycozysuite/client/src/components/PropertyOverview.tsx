import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Bed, Bath, Users, Heart, Star } from "lucide-react";

export default function PropertyOverview() {
  const { data: property } = useQuery({
    queryKey: ["/api/property"],
  });

  if (!property) return null;

  return (
    <section id="property" className="py-20 bg-warm-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="flex items-center mb-4">
              <div className="flex text-warm-gold text-lg">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-5 h-5 fill-current" />
                ))}
              </div>
              <span className="ml-2 text-lg font-semibold text-charcoal">
                {property.rating}
              </span>
              <span className="ml-1 text-gray-500">
                ({property.reviewCount} reviews)
              </span>
            </div>
            
            <h2 className="font-playfair text-4xl font-bold text-navy mb-6">
              {property.title}
            </h2>
            
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              {property.description} Located in a vibrant Brooklyn neighborhood with 
              excellent transit connections to Manhattan and JFK Airport.
            </p>
            
            <div className="grid grid-cols-2 gap-6 mb-8">
              <div className="flex items-center">
                <Bed className="text-sophisticated-blue text-xl mr-3" />
                <span className="text-gray-700">{property.bedrooms} Bedrooms</span>
              </div>
              <div className="flex items-center">
                <Bath className="text-sophisticated-blue text-xl mr-3" />
                <span className="text-gray-700">{property.bathrooms} Bathroom</span>
              </div>
              <div className="flex items-center">
                <Users className="text-sophisticated-blue text-xl mr-3" />
                <span className="text-gray-700">Up to {property.maxGuests} guests</span>
              </div>
              <div className="flex items-center">
                <Heart className="text-sophisticated-blue text-xl mr-3" />
                <span className="text-gray-700">Pet-friendly</span>
              </div>
            </div>
            
            <Button 
              onClick={() => {
                const element = document.getElementById('gallery');
                if (element) {
                  element.scrollIntoView({ behavior: 'smooth' });
                }
              }}
              className="bg-sophisticated-blue text-white hover:bg-navy transition-colors"
            >
              View Full Details
            </Button>
          </div>
          
          <div className="relative">
            <img 
              src="/attached_assets/airbnb20.jpg" 
              alt="Elegant bedroom with wooden furniture and sophisticated decor" 
              className="rounded-2xl shadow-lg w-full h-auto"
            />
            <div className="absolute -bottom-8 -left-8 bg-white p-6 rounded-xl shadow-lg">
              <div className="text-center">
                <p className="text-3xl font-bold text-navy">{property.rating}</p>
                <p className="text-sm text-gray-500">Guest Rating</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
