import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const scrollToBooking = () => {
    const element = document.getElementById('booking');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 w-full bg-white/95 backdrop-blur-sm z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <h1 className="font-playfair text-2xl font-bold text-navy">Polly's Cozy Suite</h1>
          </div>
          
          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('property')}
              className="text-charcoal hover:text-sophisticated-blue transition-colors"
            >
              Property
            </button>
            <button 
              onClick={() => scrollToSection('amenities')}
              className="text-charcoal hover:text-sophisticated-blue transition-colors"
            >
              Amenities
            </button>
            <button 
              onClick={() => scrollToSection('reviews')}
              className="text-charcoal hover:text-sophisticated-blue transition-colors"
            >
              Reviews
            </button>
            <button 
              onClick={() => scrollToSection('location')}
              className="text-charcoal hover:text-sophisticated-blue transition-colors"
            >
              Location
            </button>
            <Button 
              onClick={scrollToBooking}
              className="bg-sophisticated-blue text-white hover:bg-navy transition-colors"
            >
              Book Now
            </Button>
          </div>
          
          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <Button
              variant="ghost"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-charcoal"
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>
        
        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-gray-100 py-4">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('property')}
                className="text-left text-charcoal hover:text-sophisticated-blue transition-colors"
              >
                Property
              </button>
              <button 
                onClick={() => scrollToSection('amenities')}
                className="text-left text-charcoal hover:text-sophisticated-blue transition-colors"
              >
                Amenities
              </button>
              <button 
                onClick={() => scrollToSection('reviews')}
                className="text-left text-charcoal hover:text-sophisticated-blue transition-colors"
              >
                Reviews
              </button>
              <button 
                onClick={() => scrollToSection('location')}
                className="text-left text-charcoal hover:text-sophisticated-blue transition-colors"
              >
                Location
              </button>
              <Button 
                onClick={scrollToBooking}
                className="bg-sophisticated-blue text-white hover:bg-navy transition-colors w-full"
              >
                Book Now
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}
