import { Wifi, Car, Tv, Snowflake, UtensilsCrossed, Shield, Baby, Shirt, Key } from "lucide-react";

const amenities = [
  {
    icon: Wifi,
    title: "High-Speed WiFi",
    description: "Reliable internet perfect for remote work and streaming"
  },
  {
    icon: Car,
    title: "Free Parking",
    description: "Complimentary on-premises and street parking available"
  },
  {
    icon: Tv,
    title: "55\" Smart TV",
    description: "Large HDTV with streaming services and cable"
  },
  {
    icon: Snowflake,
    title: "Air Conditioning",
    description: "Individual AC units in each room for optimal comfort"
  },
  {
    icon: UtensilsCrossed,
    title: "Full Kitchen",
    description: "Complete with gas stove, refrigerator, and cooking essentials"
  },
  {
    icon: Shield,
    title: "Safety Features",
    description: "Smoke alarm, carbon monoxide detector, and first aid kit"
  },
  {
    icon: Baby,
    title: "Family Friendly",
    description: "Children's books, toys, and dinnerware provided"
  },
  {
    icon: Shirt,
    title: "Laundry Access",
    description: "Iron and nearby laundromat for extended stays"
  },
  {
    icon: Key,
    title: "Self Check-in",
    description: "Convenient lockbox system for flexible arrival times"
  }
];

export default function AmenitiesSection() {
  return (
    <section id="amenities" className="py-20 bg-warm-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="font-playfair text-4xl font-bold text-navy text-center mb-16">
          Premium Amenities
        </h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {amenities.map((amenity, index) => {
            const IconComponent = amenity.icon;
            return (
              <div 
                key={index}
                className="bg-white p-6 rounded-xl shadow-sm hover:shadow-md transition-shadow"
              >
                <IconComponent className="text-sophisticated-blue w-8 h-8 mb-4" />
                <h3 className="font-semibold text-lg mb-2">{amenity.title}</h3>
                <p className="text-gray-600">{amenity.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
