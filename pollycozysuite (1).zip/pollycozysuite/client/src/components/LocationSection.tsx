import { TrainFront, Bus, Plane, Building, ShoppingBag, Gamepad2, UtensilsCrossed } from "lucide-react";

export default function LocationSection() {
  return (
    <section id="location" className="py-20 bg-warm-gray">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="font-playfair text-4xl font-bold text-navy text-center mb-16">
          Location & Neighborhood
        </h2>
        
        <div className="grid lg:grid-cols-2 gap-16">
          <div>
            <h3 className="font-playfair text-2xl font-semibold text-navy mb-6">
              Brooklyn, New York
            </h3>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Located in a vibrant Brooklyn neighborhood with a diverse community of White, Chinese, 
              Hispanic, and Caribbean residents. The area offers excellent connectivity to Manhattan 
              and major airports, making it perfect for both business and leisure travelers.
            </p>
            
            <div className="space-y-6">
              <div>
                <h4 className="font-semibold text-lg text-charcoal mb-3">Transportation</h4>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center">
                    <TrainFront className="text-sophisticated-blue mr-3 w-5 h-5" />
                    <span className="text-gray-600">J, Z, A, C, #3 trains</span>
                  </div>
                  <div className="flex items-center">
                    <Bus className="text-sophisticated-blue mr-3 w-5 h-5" />
                    <span className="text-gray-600">Q24, B15, B14, B6 buses</span>
                  </div>
                  <div className="flex items-center">
                    <Plane className="text-sophisticated-blue mr-3 w-5 h-5" />
                    <span className="text-gray-600">22 min to JFK Airport</span>
                  </div>
                  <div className="flex items-center">
                    <Building className="text-sophisticated-blue mr-3 w-5 h-5" />
                    <span className="text-gray-600">22 min to Downtown Brooklyn</span>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-semibold text-lg text-charcoal mb-3">Nearby Attractions</h4>
                <ul className="space-y-2 text-gray-600">
                  <li className="flex items-center">
                    <ShoppingBag className="text-sophisticated-blue mr-3 w-5 h-5" />
                    Gateway Mall - Shopping and entertainment
                  </li>
                  <li className="flex items-center">
                    <Gamepad2 className="text-sophisticated-blue mr-3 w-5 h-5" />
                    Barclays Center - Sports and events
                  </li>
                  <li className="flex items-center">
                    <UtensilsCrossed className="text-sophisticated-blue mr-3 w-5 h-5" />
                    Diverse dining options nearby
                  </li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-lg text-charcoal mb-3">Dining Options</h4>
                <p className="text-gray-600">
                  Caribbean cuisine, Olive Garden, Applebee's, Dave & Buster's, Chinese restaurants, 
                  Domino's Pizza, Wendy's, Burger King, and many local favorites within walking distance.
                </p>
              </div>
            </div>
          </div>
          
          <div className="relative">
            <img 
              src="/attached_assets/airbnb11.jpg" 
              alt="Bright and airy living space with excellent natural lighting" 
              className="rounded-2xl shadow-lg w-full h-auto"
            />
            
            <div className="absolute -bottom-6 -right-6 bg-white p-4 rounded-xl shadow-lg">
              <div className="text-center">
                <p className="text-lg font-bold text-navy">22 min</p>
                <p className="text-sm text-gray-500">to JFK Airport</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
