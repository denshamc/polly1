import { useState } from "react";

const galleryImages = [
  {
    src: "/attached_assets/airbnb 4.jpg",
    alt: "Elegant living room with sophisticated blue walls and comfortable seating"
  },
  {
    src: "/attached_assets/airbnb20.jpg",
    alt: "Master bedroom with elegant wooden furniture and blue decor"
  },
  {
    src: "/attached_assets/airbnb21.jpg",
    alt: "Second bedroom with white headboard and cozy atmosphere"
  },
  {
    src: "/attached_assets/airbnb24.jpg",
    alt: "Modern bathroom with white subway tiles and dark accent wall"
  },
  {
    src: "/attached_assets/airbnb25.jpg",
    alt: "Bathroom storage with fresh towels and premium amenities"
  },
  {
    src: "/attached_assets/airbnb9.jpg",
    alt: "Open concept living space with kitchen view"
  },
  {
    src: "/attached_assets/airbnb10.jpg",
    alt: "Cozy living area with warm lighting and comfortable furnishings"
  },
  {
    src: "/attached_assets/airbnb11.jpg",
    alt: "Spacious living room with natural light and plants"
  },
  {
    src: "/attached_assets/airbnb12.jpg",
    alt: "Living space showcasing the open kitchen design"
  },
  {
    src: "/attached_assets/airbnb13.jpg",
    alt: "Bright living area with multiple windows and colorful accents"
  },
  {
    src: "/attached_assets/airbnb 16.jpg",
    alt: "Dining area with elegant table setting and artwork"
  },
  {
    src: "/attached_assets/airbnb 30.jpg",
    alt: "Welcome entrance with personalized door greeting"
  }
];

export default function ImageGallery() {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  return (
    <section id="gallery" className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="font-playfair text-4xl font-bold text-navy text-center mb-12">
          Property Gallery
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <div 
              key={index}
              className="relative overflow-hidden rounded-xl group cursor-pointer"
              onClick={() => setSelectedImage(image.src)}
            >
              <img 
                src={image.src} 
                alt={image.alt} 
                className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
            </div>
          ))}
        </div>
        
        {/* Modal for selected image */}
        {selectedImage && (
          <div 
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <div className="relative max-w-4xl max-h-full">
              <img 
                src={selectedImage} 
                alt="Full size image" 
                className="max-w-full max-h-full object-contain rounded-lg"
              />
              <button 
                onClick={() => setSelectedImage(null)}
                className="absolute top-4 right-4 text-white bg-black/50 rounded-full p-2 hover:bg-black/70 transition-colors"
              >
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
          </div>
        )}
      </div>
    </section>
  );
}
