import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertBookingSchema, insertReviewSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all reviews
  app.get("/api/reviews", async (_req, res) => {
    try {
      const reviews = await storage.getReviews();
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch reviews" });
    }
  });

  // Create a new booking
  app.post("/api/bookings", async (req, res) => {
    try {
      const validatedData = insertBookingSchema.parse(req.body);
      const booking = await storage.createBooking(validatedData);
      res.status(201).json(booking);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid booking data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create booking" });
      }
    }
  });

  // Get all bookings
  app.get("/api/bookings", async (_req, res) => {
    try {
      const bookings = await storage.getBookings();
      res.json(bookings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch bookings" });
    }
  });

  // Create a new review
  app.post("/api/reviews", async (req, res) => {
    try {
      const validatedData = insertReviewSchema.parse(req.body);
      const review = await storage.createReview(validatedData);
      res.status(201).json(review);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid review data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create review" });
      }
    }
  });

  // Get property information (mock data)
  app.get("/api/property", async (_req, res) => {
    try {
      const propertyData = {
        id: 1,
        title: "Polly's Cozy Suite - Comfortable Brooklyn Home",
        description: "Welcome to Polly's warm and inviting home! This thoughtfully appointed 2-bedroom suite features cozy furnishings, essential amenities, and personal touches that make every guest feel at home.",
        bedrooms: 2,
        bathrooms: 1,
        maxGuests: 6,
        basePrice: 125,
        cleaningFee: 25,
        rating: 4.96,
        reviewCount: 50,
        petFriendly: true,
        ratings: {
          cleanliness: 4.9,
          accuracy: 5.0,
          checkin: 4.9,
          communication: 5.0,
          location: 4.7,
          value: 4.9,
        },
      };
      res.json(propertyData);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch property data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
