import { 
  users, 
  bookings, 
  reviews, 
  type User, 
  type InsertUser, 
  type Booking, 
  type InsertBooking, 
  type Review, 
  type InsertReview 
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createBooking(booking: InsertBooking): Promise<Booking>;
  getBookings(): Promise<Booking[]>;
  getBooking(id: number): Promise<Booking | undefined>;
  getReviews(): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private bookings: Map<number, Booking>;
  private reviews: Map<number, Review>;
  private currentUserId: number;
  private currentBookingId: number;
  private currentReviewId: number;

  constructor() {
    this.users = new Map();
    this.bookings = new Map();
    this.reviews = new Map();
    this.currentUserId = 1;
    this.currentBookingId = 1;
    this.currentReviewId = 1;

    // Initialize with sample reviews from the provided data
    this.initializeReviews();
  }

  private initializeReviews() {
    const sampleReviews: InsertReview[] = [
      {
        guestName: "Jeffrey",
        location: "Holland, Michigan",
        rating: 5,
        reviewText: "Polly has a beautiful place! Just as nice if not even nicer and more spacious in person. Very nice and responsive and welcoming and at the same time felt very private! I also forgot something after checking out and she is even kind enough to send it back to me! Amazing host and I will definitely live to stay here again!",
        stayDate: "1 week ago",
        verified: true,
      },
      {
        guestName: "Sean",
        location: "Midlothian, Texas",
        rating: 5,
        reviewText: "Great host beautiful space with very comfy beds. Would recommend and stay again",
        stayDate: "January 2025",
        verified: true,
      },
      {
        guestName: "Waleed",
        location: "Atlanta, Georgia",
        rating: 5,
        reviewText: "The house is very nice, organised, and clean, I loved it and I will have it as the first option when visiting again.",
        stayDate: "December 2024",
        verified: true,
      },
      {
        guestName: "Tyra",
        location: "8 months on Airbnb",
        rating: 5,
        reviewText: "Staying at Polly's place was a wonderful experience. She was very nice and considerate. The place was clean and enjoyable to stay in. The apartment was well sized for me and my friend's stay.",
        stayDate: "December 2024",
        verified: true,
      },
      {
        guestName: "Lana",
        location: "Toronto, Canada",
        rating: 5,
        reviewText: "Polly went above and beyond to ensure that our stay was comfortable. The space is extremely clean, stocked with all necessities and well decorated. I really appreciated her responsiveness to all of our needs. Polly and her home were lovely. Thank you!",
        stayDate: "June 2023",
        verified: true,
      },
      {
        guestName: "Jaydie",
        location: "12 years on Airbnb",
        rating: 5,
        reviewText: "Exactly as listed and pictures true to the apartment. Polly was extremely helpful and communicative. I would recommended her place and will be back again.",
        stayDate: "June 2023",
        verified: true,
      },
    ];

    sampleReviews.forEach(review => {
      const id = this.currentReviewId++;
      this.reviews.set(id, { ...review, id });
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createBooking(insertBooking: InsertBooking): Promise<Booking> {
    const id = this.currentBookingId++;
    const booking: Booking = {
      ...insertBooking,
      id,
      status: "pending",
      createdAt: new Date(),
    };
    this.bookings.set(id, booking);
    return booking;
  }

  async getBookings(): Promise<Booking[]> {
    return Array.from(this.bookings.values());
  }

  async getBooking(id: number): Promise<Booking | undefined> {
    return this.bookings.get(id);
  }

  async getReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values());
  }

  async createReview(insertReview: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const review: Review = { ...insertReview, id };
    this.reviews.set(id, review);
    return review;
  }
}

export const storage = new MemStorage();
